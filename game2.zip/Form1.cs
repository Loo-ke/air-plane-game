﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace game2
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            movecloud(5);
            Missile(4);
            Coin(4);
            GameOver();
        }
        Random random = new Random();
        int x;
        int y;
        void movecloud(int speed)
        {
            if (cloud1.Top >= 500)
            {
                x = random.Next(0, 225);
                
                cloud1.Location = new Point(x, 0);
            }
            else
            {
                cloud1.Top += speed;
            }

            if (cloud2.Top >= 500)
            {
                x = random.Next(225, 420);
                
                cloud2.Location = new Point(x, 0);
            }
            else
            {
                cloud2.Top += speed;
            }
            
        }
        void Missile(int speed)
        {
            if (missile1.Top >= 500)
            {
                x = random.Next(0, 150);
                y = random.Next(0, 10);
                missile1.Location = new Point(x, y);
            }
            else
            {
                missile1.Top += speed;
            }

            if (missile2.Top >= 500)
            {
                x = random.Next(150, 300);
                y = random.Next(0, 30);
                missile2.Location = new Point(x, y);
            }
            else
            {
                missile2.Top += speed;
            }

            if (missile3.Top >= 500)
            {
                x = random.Next(300, 420);
                y = random.Next(0, 50);
                missile3.Location = new Point(x, y);
            }
            else
            {
                missile3.Top += speed;
            }
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {

        }

        private void Form1_KeyDown(object sender, KeyEventArgs e)
        {
            if(e.KeyCode == Keys.Left)
            {
                if(airplaneImg.Left > 20)
                {
                airplaneImg.Left += -50;
                }
            }
            else if(e.KeyCode == Keys.Right)
            {
                if(airplaneImg.Right < 450 - airplaneImg.Width /2)
                {
                    airplaneImg.Left += 50;
                }
            }
            
        }
        int score = 0;
        void Coin(int speed)
        {
            if (coin1.Top >= 500)
            {
                x = random.Next(0, 420);
                coin1.Location = new Point(x, 0);
            }
            else if(airplaneImg.Bounds.IntersectsWith(coin1.Bounds))
            {
                x = random.Next(0, 420);
                coin1.Location = new Point(x, 0);
                score++;
                lblScore.Text = score.ToString();   
            }
            else
            {
                coin1.Top += speed;
            }
        }
        void GameOver()
        {
            if (airplaneImg.Bounds.IntersectsWith(missile1.Bounds))
            {
                timer1.Enabled = false;
                lblGameOver.Visible = true;

            }
            if (airplaneImg.Bounds.IntersectsWith(missile2.Bounds))
            {
                timer1.Enabled = false;
                lblGameOver.Visible = true;

            }
            if (airplaneImg.Bounds.IntersectsWith(missile3.Bounds))
            {
                timer1.Enabled = false;
                lblGameOver.Visible = true;

            }
        }
    }

}
