﻿namespace game2
{
    partial class Form1
    {
        /// <summary>
        /// 필수 디자이너 변수입니다.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 사용 중인 모든 리소스를 정리합니다.
        /// </summary>
        /// <param name="disposing">관리되는 리소스를 삭제해야 하면 true이고, 그렇지 않으면 false입니다.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form 디자이너에서 생성한 코드

        /// <summary>
        /// 디자이너 지원에 필요한 메서드입니다. 
        /// 이 메서드의 내용을 코드 편집기로 수정하지 마세요.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.cloud1 = new System.Windows.Forms.PictureBox();
            this.cloud2 = new System.Windows.Forms.PictureBox();
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.missile1 = new System.Windows.Forms.PictureBox();
            this.missile2 = new System.Windows.Forms.PictureBox();
            this.missile3 = new System.Windows.Forms.PictureBox();
            this.airplaneImg = new System.Windows.Forms.PictureBox();
            this.lblGameOver = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.lblScore = new System.Windows.Forms.Label();
            this.coin1 = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.cloud1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.cloud2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.missile1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.missile2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.missile3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.airplaneImg)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.coin1)).BeginInit();
            this.SuspendLayout();
            // 
            // cloud1
            // 
            this.cloud1.Image = ((System.Drawing.Image)(resources.GetObject("cloud1.Image")));
            this.cloud1.Location = new System.Drawing.Point(144, 277);
            this.cloud1.Name = "cloud1";
            this.cloud1.Size = new System.Drawing.Size(80, 70);
            this.cloud1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.cloud1.TabIndex = 0;
            this.cloud1.TabStop = false;
            // 
            // cloud2
            // 
            this.cloud2.Image = ((System.Drawing.Image)(resources.GetObject("cloud2.Image")));
            this.cloud2.Location = new System.Drawing.Point(257, 32);
            this.cloud2.Name = "cloud2";
            this.cloud2.Size = new System.Drawing.Size(80, 70);
            this.cloud2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.cloud2.TabIndex = 1;
            this.cloud2.TabStop = false;
            // 
            // timer1
            // 
            this.timer1.Enabled = true;
            this.timer1.Interval = 10;
            this.timer1.Tick += new System.EventHandler(this.timer1_Tick);
            // 
            // missile1
            // 
            this.missile1.Image = ((System.Drawing.Image)(resources.GetObject("missile1.Image")));
            this.missile1.Location = new System.Drawing.Point(38, 349);
            this.missile1.Name = "missile1";
            this.missile1.Size = new System.Drawing.Size(40, 60);
            this.missile1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.missile1.TabIndex = 2;
            this.missile1.TabStop = false;
            // 
            // missile2
            // 
            this.missile2.Image = ((System.Drawing.Image)(resources.GetObject("missile2.Image")));
            this.missile2.Location = new System.Drawing.Point(191, 12);
            this.missile2.Name = "missile2";
            this.missile2.Size = new System.Drawing.Size(40, 60);
            this.missile2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.missile2.TabIndex = 3;
            this.missile2.TabStop = false;
            this.missile2.Click += new System.EventHandler(this.pictureBox1_Click);
            // 
            // missile3
            // 
            this.missile3.Image = ((System.Drawing.Image)(resources.GetObject("missile3.Image")));
            this.missile3.Location = new System.Drawing.Point(342, 187);
            this.missile3.Name = "missile3";
            this.missile3.Size = new System.Drawing.Size(40, 60);
            this.missile3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.missile3.TabIndex = 4;
            this.missile3.TabStop = false;
            // 
            // airplaneImg
            // 
            this.airplaneImg.Image = ((System.Drawing.Image)(resources.GetObject("airplaneImg.Image")));
            this.airplaneImg.Location = new System.Drawing.Point(181, 359);
            this.airplaneImg.Name = "airplaneImg";
            this.airplaneImg.Size = new System.Drawing.Size(70, 70);
            this.airplaneImg.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.airplaneImg.TabIndex = 5;
            this.airplaneImg.TabStop = false;
            // 
            // lblGameOver
            // 
            this.lblGameOver.AutoSize = true;
            this.lblGameOver.BackColor = System.Drawing.Color.Gold;
            this.lblGameOver.Font = new System.Drawing.Font("굴림", 48F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.lblGameOver.ForeColor = System.Drawing.Color.Red;
            this.lblGameOver.Location = new System.Drawing.Point(17, 183);
            this.lblGameOver.Name = "lblGameOver";
            this.lblGameOver.Size = new System.Drawing.Size(403, 64);
            this.lblGameOver.TabIndex = 6;
            this.lblGameOver.Text = "GAME OVER";
            this.lblGameOver.Visible = false;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("굴림", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label1.Location = new System.Drawing.Point(280, 433);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(82, 19);
            this.label1.TabIndex = 7;
            this.label1.Text = "score : ";
            // 
            // lblScore
            // 
            this.lblScore.AutoSize = true;
            this.lblScore.Font = new System.Drawing.Font("굴림", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.lblScore.Location = new System.Drawing.Point(368, 433);
            this.lblScore.Name = "lblScore";
            this.lblScore.Size = new System.Drawing.Size(0, 19);
            this.lblScore.TabIndex = 8;
            // 
            // coin1
            // 
            this.coin1.Image = ((System.Drawing.Image)(resources.GetObject("coin1.Image")));
            this.coin1.Location = new System.Drawing.Point(70, 108);
            this.coin1.Name = "coin1";
            this.coin1.Size = new System.Drawing.Size(30, 30);
            this.coin1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.coin1.TabIndex = 9;
            this.coin1.TabStop = false;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(434, 461);
            this.Controls.Add(this.coin1);
            this.Controls.Add(this.lblScore);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.lblGameOver);
            this.Controls.Add(this.airplaneImg);
            this.Controls.Add(this.missile3);
            this.Controls.Add(this.missile2);
            this.Controls.Add(this.missile1);
            this.Controls.Add(this.cloud2);
            this.Controls.Add(this.cloud1);
            this.Name = "Form1";
            this.Text = "Form1";
            this.KeyDown += new System.Windows.Forms.KeyEventHandler(this.Form1_KeyDown);
            ((System.ComponentModel.ISupportInitialize)(this.cloud1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.cloud2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.missile1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.missile2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.missile3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.airplaneImg)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.coin1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.PictureBox cloud1;
        private System.Windows.Forms.PictureBox cloud2;
        private System.Windows.Forms.Timer timer1;
        private System.Windows.Forms.PictureBox missile1;
        private System.Windows.Forms.PictureBox missile2;
        private System.Windows.Forms.PictureBox missile3;
        private System.Windows.Forms.PictureBox airplaneImg;
        private System.Windows.Forms.Label lblGameOver;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label lblScore;
        private System.Windows.Forms.PictureBox coin1;
    }
}

