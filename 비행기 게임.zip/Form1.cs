﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace game2
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            movecloud(5);
            Missile(8);
            Coin(4);
            MyMissile(4);
            GameOver();
        }
        Random random = new Random();
        int x;
        int y;
        void movecloud(int speed)
        {
            if (cloud1.Top >= 800)
            {
                x = random.Next(0, 800);

                cloud1.Location = new Point(x, 0);
            }
            else
            {
                cloud1.Top += speed;
            }

            if (cloud2.Top >= 800)
            {
                x = random.Next(0, 800);

                cloud2.Location = new Point(x, 0);
            }
            else
            {
                cloud2.Top += speed;
            }

            if (cloud3.Top >= 800)
            {
                x = random.Next(0, 800);

                cloud3.Location = new Point(x, 0);
            }
            else
            {
                cloud3.Top += speed;
            }

            if (cloud4.Top >= 800)
            {
                x = random.Next(0, 800);

                cloud4.Location = new Point(x, 0);
            }
            else
            {
                cloud4.Top += speed;
            }

            if (cloud5.Top >= 800)
            {
                x = random.Next(0, 800);

                cloud5.Location = new Point(x, 0);
            }
            else
            {
                cloud5.Top += speed;
            }

        }
        int w;
        int h;
        void MyMissile(int speed)
        {
            if (myMissile.Top <= 0)
            {
                w = airplaneImg.Location.X;
                h = airplaneImg.Location.Y;
                myMissile.Location = new Point(w + 10, h);
            }
            else
            {
                myMissile.Top += -speed;
            }

            if (myMissile2.Top <= 0)
            {
                w = airplaneImg.Location.X;
                h = airplaneImg.Location.Y;
                myMissile2.Location = new Point(w + 45, h);

            }
            else
            {
                myMissile2.Top += -speed;
            }
        }
        void Missile(int speed)
        {
            if (missile1.Top >= 800)
            {
                x = random.Next(0, 160);
                y = random.Next(0, 10);
                missile1.Location = new Point(x, y);
            }
            else if (missile1.Bounds.IntersectsWith(myMissile.Bounds))
            {
                x = random.Next(0, 160);
                y = random.Next(0, 10);
                missile1.Location = new Point(x, y);
            }
            else if (missile1.Bounds.IntersectsWith(myMissile2.Bounds))
            {
                x = random.Next(0, 160);
                y = random.Next(0, 10);
                missile1.Location = new Point(x, y);
            }
            else
            {
                missile1.Top += speed;
            }

            if (missile2.Top >= 800)
            {
                x = random.Next(160, 320);
                y = random.Next(0, 30);
                missile2.Location = new Point(x, y);
            }
            else if (missile2.Bounds.IntersectsWith(myMissile.Bounds))
            {
                x = random.Next(160, 320);
                y = random.Next(0, 10);
                missile2.Location = new Point(x, y);
            }
            else if (missile2.Bounds.IntersectsWith(myMissile2.Bounds))
            {
                x = random.Next(160, 320);
                y = random.Next(0, 10);
                missile2.Location = new Point(x, y);
            }
            else
            {
                missile2.Top += speed;
            }

            if (missile3.Top >= 800)
            {
                x = random.Next(320, 480);
                y = random.Next(0, 50);
                missile3.Location = new Point(x, y);
            }
            else if (missile3.Bounds.IntersectsWith(myMissile.Bounds))
            {
                x = random.Next(320, 480);
                y = random.Next(0, 10);
                missile3.Location = new Point(x, y);
            }
            else if (missile3.Bounds.IntersectsWith(myMissile2.Bounds))
            {
                x = random.Next(0, 160);
                y = random.Next(0, 10);
                missile3.Location = new Point(x, y);
            }
            else
            {
                missile3.Top += speed;
            }

            if (missile4.Top >= 800)
            {
                x = random.Next(480, 640);
                y = random.Next(0, 10);
                missile4.Location = new Point(x, y);
            }
            else if (missile4.Bounds.IntersectsWith(myMissile.Bounds))
            {
                x = random.Next(480, 640);
                y = random.Next(0, 10);
                missile4.Location = new Point(x, y);
            }
            else if (missile4.Bounds.IntersectsWith(myMissile2.Bounds))
            {
                x = random.Next(480, 640);
                y = random.Next(0, 10);
                missile4.Location = new Point(x, y);
            }
            else
            {
                missile4.Top += speed;
            }

            if (missile5.Top >= 800)
            {
                x = random.Next(640, 780);
                y = random.Next(0, 50);
                missile5.Location = new Point(x, y);
            }
            else if (missile5.Bounds.IntersectsWith(myMissile.Bounds))
            {
                x = random.Next(640, 780);
                y = random.Next(0, 10);
                missile5.Location = new Point(x, y);
            }
            else if (missile5.Bounds.IntersectsWith(myMissile2.Bounds))
            {
                x = random.Next(640, 780);
                y = random.Next(0, 10);
                missile5.Location = new Point(x, y);
            }
            else
            {
                missile5.Top += speed;
            }
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {

        }

        private void Form1_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Left)
            {
                if (airplaneImg.Left > 20)
                {
                    airplaneImg.Left += -50;
                }
            }
            else if (e.KeyCode == Keys.Right)
            {
                if (airplaneImg.Right < 800 - airplaneImg.Width / 2)
                {
                    airplaneImg.Left += 50;
                }
            }
            else if (e.KeyCode == Keys.Up)
            {
                if (airplaneImg.Top > 20)
                {
                    airplaneImg.Top += -50;
                }
            }
            else if (e.KeyCode == Keys.Down)
            {
                if (airplaneImg.Bottom <= 730)
                {
                    airplaneImg.Top += 50;
                }
            }
        }



        int score = 0;
        void Coin(int speed)
        {
            if (coin1.Top >= 800)
            {
                x = random.Next(0, 135);
                coin1.Location = new Point(x, 0);
            }
            else if (airplaneImg.Bounds.IntersectsWith(coin1.Bounds))
            {
                x = random.Next(0, 135);
                coin1.Location = new Point(x, 0);
                score++;
                lblScore.Text = score.ToString();
            }
            else
            {
                coin1.Top += speed;
            }

            if (coin2.Top >= 800)
            {
                x = random.Next(135, 270);
                coin2.Location = new Point(x, 0);
            }
            else if (airplaneImg.Bounds.IntersectsWith(coin2.Bounds))
            {
                x = random.Next(135, 270);
                coin2.Location = new Point(x, 0);
                score++;
                lblScore.Text = score.ToString();
            }
            else
            {
                coin2.Top += speed;
            }

            if (coin3.Top >= 800)
            {
                x = random.Next(270, 405);
                coin3.Location = new Point(x, 0);
            }
            else if (airplaneImg.Bounds.IntersectsWith(coin3.Bounds))
            {
                x = random.Next(270, 405);
                coin3.Location = new Point(x, 0);
                score++;
                lblScore.Text = score.ToString();
            }
            else
            {
                coin3.Top += speed;
            }

            if (coin4.Top >= 800)
            {
                x = random.Next(405, 540);
                coin4.Location = new Point(x, 0);
            }
            else if (airplaneImg.Bounds.IntersectsWith(coin4.Bounds))
            {
                x = random.Next(405, 540);
                coin4.Location = new Point(x, 0);
                score++;
                lblScore.Text = score.ToString();
            }
            else
            {
                coin4.Top += speed;
            }

            if (coin5.Top >= 800)
            {
                x = random.Next(540, 675);
                coin5.Location = new Point(x, 0);
            }
            else if (airplaneImg.Bounds.IntersectsWith(coin5.Bounds))
            {
                x = random.Next(540, 675);
                coin5.Location = new Point(x, 0);
                score++;
                lblScore.Text = score.ToString();
            }
            else
            {
                coin5.Top += speed;
            }

            if (coin6.Top >= 800)
            {
                x = random.Next(675, 780);
                coin6.Location = new Point(x, 0);
            }
            else if (airplaneImg.Bounds.IntersectsWith(coin6.Bounds))
            {
                x = random.Next(675, 780);
                coin6.Location = new Point(x, 0);
                score++;
                lblScore.Text = score.ToString();
            }
            else
            {
                coin6.Top += speed;
            }
        }
        void GameOver()
        {
            if (airplaneImg.Bounds.IntersectsWith(missile1.Bounds))
            {
                timer1.Enabled = false;
                lblGameOver.Visible = true;

            }
            else if (airplaneImg.Bounds.IntersectsWith(missile2.Bounds))
            {
                timer1.Enabled = false;
                lblGameOver.Visible = true;
            }
            else if (airplaneImg.Bounds.IntersectsWith(missile3.Bounds))
            {
                timer1.Enabled = false;
                lblGameOver.Visible = true;
            }
            else if (airplaneImg.Bounds.IntersectsWith(missile4.Bounds))
            {
                timer1.Enabled = false;
                lblGameOver.Visible = true;
            }
            else if (airplaneImg.Bounds.IntersectsWith(missile5.Bounds))
            {
                timer1.Enabled = false;
                lblGameOver.Visible = true;
            }
        }

        private void airplaneImg_Click(object sender, EventArgs e)
        {

        }

        private void pictureBox2_Click(object sender, EventArgs e)
        {

        }

        private void pictureBox4_Click(object sender, EventArgs e)
        {

        }
    }

}
